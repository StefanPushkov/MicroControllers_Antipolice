String APN_param = "\"internet.mts.ru\",\"mts\",\"mts\"";
String serv_port_UDP = "\"UDP\",\"52.143.153.221\",\"8080\"";
String serv_port_TCP = "\"TCP\",\"52.143.153.221\",\"80\"";

void restartGSM(){                               //Функия перезагрузки GPRS Модуля
    digitalWrite(9, HIGH);    
    delay(1000);
    digitalWrite(9, LOW);
    delay(2000);  
    digitalWrite(9, HIGH);
    delay(1000);
    digitalWrite(9, LOW);
    delay(10000);                               //Даём время подумоть...
}

String waitResponse() {                         // Функция ожидания ответа и возврата полученного результата
  String _resp = "";                            // Переменная для хранения результата
  long _timeout = millis() + 20000;             // Переменная для отслеживания таймаута (10 секунд)
  while (!SIM900.available() && millis() < _timeout)  {}; // Ждем ответа 10 секунд, если пришел ответ или наступил таймаут, то...
  if (SIM900.available()) {                     // Если есть, что считывать...
    _resp = SIM900.readString();                // ... считываем и запоминаем
  }
  else {                                        // Если пришел таймаут, то...
    _resp = "Timeout...";                       // ... оповещаем об этом и...
  }
  return _resp;                                 // ... возвращаем результат. Пусто, если проблема
}

String sendATCommand(String cmd, bool waiting) {
  String _resp = "";                            // Переменная для хранения результата
  Serial.println(cmd);                          // Дублируем команду в монитор порта
  SIM900.println(cmd);                          // Отправляем команду модулю
  if (waiting) {                                // Если необходимо дождаться ответа...
    _resp = waitResponse();                     // ... ждем, когда будет передан ответ
    // Если Echo Mode выключен (ATE0), то эти 3 строки можно закомментировать
   // if (_resp.startsWith(cmd)) {                // Убираем из ответа дублирующуюся команду
   //   _resp = _resp.substring(_resp.indexOf("\r", cmd.length()) + 2);
   // }
    Serial.println(_resp);                      // Дублируем ответ в монитор порта
  }
  return _resp;                                 // Возвращаем результат. Пусто, если проблема
}

void sendSMS(String phone, String message) {
  sendATCommand("AT+CMGS=\"" + phone + "\"", true);             // Переходим в режим ввода текстового сообщения
  sendATCommand(message + "\r\n" + (String)((char)26), true);   // После текста отправляем перенос строки и Ctrl+Z
}

void sendUDP(String message) {
  String response = "";
  while (response != ""){
  sendATCommand("AT", true);
  sendATCommand("AT+CIPSHUT", true);
  sendATCommand("AT+CIPMUX=0", true);
  sendATCommand("AT+CGATT=1", true);
  sendATCommand("AT+CSTT="+APN_param, true);
  sendATCommand("AT+CIICR", true);
  sendATCommand("AT+CIFSR", true);
  sendATCommand("AT+CIPSTART="+serv_port_UDP, true);
  sendATCommand("AT+CIPSEND", true);
  sendATCommand(message + "\r\n" + (String)((char)26), true);
  if (SIM900.available()) {                     // Если есть, что считывать...
    response = SIM900.readString();                // ... считываем и запоминаем
  }
  else {                                        // Если пришел таймаут, то...
    response = "";               // ... оповещаем об этом и...
  }
  sendATCommand("AT+CIPCLOSE", true);
  }
}



void sendTCP(String message) {
  PleaseWork:
  String response = "ERROR";
  while (response.startsWith("ERROR")){
  sendATCommand("AT", true);
  sendATCommand("AT+CIPSHUT", true);
  sendATCommand("AT+CIPMUX=0", true);
  sendATCommand("AT+CGATT=1", true);
  sendATCommand("AT+CSTT="+APN_param, true);
  sendATCommand("AT+CIICR", true);
  sendATCommand("AT+CIFSR", true);
  sendATCommand("AT+CIPSTART="+serv_port_TCP, true);
  sendATCommand("AT+CIPSEND", true);
  sendATCommand(message + "\r\n" + (String)((char)26), true);
  Serial.println("Response is:" + response);
  sendATCommand("AT+CIPCLOSE", true);
  }
  
}
